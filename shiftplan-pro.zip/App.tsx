import React, { useState, useEffect } from 'react';
import { CalendarGrid } from './components/CalendarGrid';
import { AdminPanel } from './components/AdminPanel';
import { usePlanner } from './hooks/usePlanner';
import { Loader2, AlertCircle, Moon, Sun } from 'lucide-react';

const App: React.FC = () => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  
  // Theme State
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('theme') === 'dark' ? 'dark' : 'light';
    }
    return 'light';
  });

  // Apply Theme Effect
  useEffect(() => {
    const root = window.document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem('theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prev => prev === 'light' ? 'dark' : 'light');
  };

  const {
    loading, error,
    users, addUser, removeUser, updateUser,
    templates, addTemplate, removeTemplate, updateTemplate,
    holidays, toggleHoliday, moveAssignment,
    getAssignment, toggleAssignmentTemplate, updateAssignmentText, clearAssignment, replaceAssignment
  } = usePlanner();

  if (loading) {
    return (
      <div className="h-screen w-full flex flex-col items-center justify-center bg-slate-100 dark:bg-slate-900 text-slate-500 dark:text-slate-400 gap-4">
        <Loader2 className="w-10 h-10 animate-spin text-blue-600" />
        <p className="font-medium">Chargement du planning partagé...</p>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col bg-slate-100 dark:bg-slate-950 transition-colors duration-200">
      {/* Top Navigation Bar */}
      <nav className="bg-white dark:bg-slate-900 border-b dark:border-slate-800 px-6 py-3 flex items-center justify-between shadow-sm z-20 transition-colors">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center shadow-lg shadow-blue-900/20">
            <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <div>
            <h1 className="text-lg font-bold text-slate-800 dark:text-white leading-tight">ShiftPlan Pro</h1>
            <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                {error ? <span className="text-red-500 flex items-center gap-1"><AlertCircle className="w-3 h-3"/> Déconnecté</span> : 'En ligne - Synchronisé'}
            </p>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
           {/* Dark Mode Toggle */}
           <button 
             onClick={toggleTheme}
             className="p-2 rounded-full text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800 transition-colors"
             title={theme === 'dark' ? "Passer en mode clair" : "Passer en mode sombre"}
           >
             {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
           </button>

           <div className="h-6 w-px bg-slate-200 dark:bg-slate-700 mx-1 hidden md:block"></div>

           <div className="text-sm text-slate-500 dark:text-slate-400 hidden md:block">
              Bienvenue, <strong>Admin</strong>
           </div>
           <div className="w-8 h-8 rounded-full bg-slate-200 dark:bg-slate-700 border-2 border-white dark:border-slate-600 shadow-sm overflow-hidden">
             <img src="https://picsum.photos/100/100" alt="Avatar" className="w-full h-full object-cover" />
           </div>
        </div>
      </nav>

      {/* Main Content Area */}
      <main className="flex-1 p-4 md:p-6 overflow-hidden flex flex-col">
        {error && (
            <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-300 px-4 py-2 rounded-lg mb-4 text-sm flex items-center gap-2">
                <AlertCircle className="w-4 h-4" />
                Attention : {error}. Les modifications ne seront pas sauvegardées sur le serveur.
            </div>
        )}
        
        <div className="flex-1 h-full min-h-0">
          <CalendarGrid 
            currentDate={currentDate}
            onDateChange={setCurrentDate}
            users={users}
            templates={templates}
            holidays={holidays}
            getAssignment={getAssignment}
            onToggleTemplate={toggleAssignmentTemplate}
            onUpdateText={updateAssignmentText}
            onReplace={replaceAssignment}
            onClear={clearAssignment}
            onMoveAssignment={moveAssignment}
            onToggleHoliday={toggleHoliday}
            onOpenAdmin={() => setIsAdminOpen(true)}
          />
        </div>
      </main>

      {/* Admin Modal */}
      {isAdminOpen && (
        <AdminPanel 
          users={users}
          templates={templates}
          onAddUser={addUser}
          onRemoveUser={removeUser}
          onUpdateUser={updateUser}
          onAddTemplate={addTemplate}
          onRemoveTemplate={removeTemplate}
          onUpdateTemplate={updateTemplate}
          onClose={() => setIsAdminOpen(false)}
        />
      )}
    </div>
  );
};

export default App;