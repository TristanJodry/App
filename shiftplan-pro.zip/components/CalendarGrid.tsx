import React, { useState, useRef, useEffect } from 'react';
import { User, ShiftTemplate, Assignment } from '../types';
import { getStartOfWeek, addDays, formatDateFr, formatDateISO } from '../utils/dateUtils';
import { ChevronLeft, ChevronRight, Settings, Calendar as CalendarIcon, Check, Eraser, Plus, Type, Copy, Flag } from 'lucide-react';

interface CalendarGridProps {
  currentDate: Date;
  onDateChange: (d: Date) => void;
  users: User[];
  templates: ShiftTemplate[];
  holidays: string[];
  getAssignment: (userId: string, date: Date) => Assignment | undefined;
  onToggleTemplate: (userId: string, date: Date, templateId: string) => void;
  onUpdateText: (userId: string, date: Date, text: string) => void;
  onReplace: (userId: string, date: Date, templateIds: string[], customText: string) => void;
  onClear: (userId: string, date: Date) => void;
  onMoveAssignment: (fromUserId: string, fromDate: Date, toUserId: string, toDate: Date) => void;
  onToggleHoliday: (date: Date) => void;
  onOpenAdmin: () => void;
}

export const CalendarGrid: React.FC<CalendarGridProps> = ({
  currentDate, onDateChange, users, templates, holidays, getAssignment, onToggleTemplate, onUpdateText, onReplace, onClear, onMoveAssignment, onToggleHoliday, onOpenAdmin
}) => {
  const startOfWeek = getStartOfWeek(currentDate);
  const weekDays = Array.from({ length: 7 }, (_, i) => addDays(startOfWeek, i));
  const todayISO = formatDateISO(new Date());

  // Clipboard State
  const [clipboard, setClipboard] = useState<{templateIds: string[], customText: string} | null>(null);
  
  // Selection State (which cell is currently focused/selected)
  const [selectedCell, setSelectedCell] = useState<{userId: string, date: Date} | null>(null);

  // Drag & Drop State
  const [dragOverCell, setDragOverCell] = useState<{userId: string, dateStr: string} | null>(null);

  // Popover state
  const [popover, setPopover] = useState<{
    isOpen: boolean;
    userId: string | null;
    date: Date | null;
    x: number;
    y: number;
  }>({ isOpen: false, userId: null, date: null, x: 0, y: 0 });

  // Local text state for the input in the popover
  const [localText, setLocalText] = useState('');

  const popoverRef = useRef<HTMLDivElement>(null);

  // Load existing text into local state when opening popover
  useEffect(() => {
    if (popover.isOpen && popover.userId && popover.date) {
        const assignment = getAssignment(popover.userId, popover.date);
        setLocalText(assignment?.customText || '');
    }
  }, [popover.isOpen, popover.userId, popover.date, getAssignment]);

  // Close popover when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (popoverRef.current && !popoverRef.current.contains(event.target as Node)) {
        setPopover({ ...popover, isOpen: false });
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [popover]);

  const handleCellClick = (e: React.MouseEvent, userId: string, date: Date) => {
    setSelectedCell({ userId, date });
    (e.currentTarget as HTMLElement).focus();
  };

  const handleCellDoubleClick = (e: React.MouseEvent | React.KeyboardEvent, userId: string, date: Date) => {
    const target = e.currentTarget as HTMLElement;
    const rect = target.getBoundingClientRect();
    
    let x = rect.left + window.scrollX;
    if (x + 280 > window.innerWidth) {
        x = window.innerWidth - 290;
    }

    setPopover({
      isOpen: true,
      userId,
      date,
      x: x,
      y: rect.bottom + window.scrollY + 5
    });
  };

  const handleKeyDown = (e: React.KeyboardEvent, userId: string, date: Date) => {
    if (popover.isOpen) return;
    if (e.key === 'Enter') {
        e.preventDefault();
        handleCellDoubleClick(e, userId, date);
    }
    if (e.key === 'Delete' || e.key === 'Backspace') {
        onClear(userId, date);
    }
    if ((e.ctrlKey || e.metaKey) && e.key === 'c') {
        e.preventDefault();
        const assignment = getAssignment(userId, date);
        if (assignment) {
            setClipboard({
                templateIds: assignment.templateIds,
                customText: assignment.customText || ''
            });
        } else {
            setClipboard(null);
        }
    }
    if ((e.ctrlKey || e.metaKey) && e.key === 'v') {
        e.preventDefault();
        if (clipboard) {
            onReplace(userId, date, clipboard.templateIds, clipboard.customText);
        }
    }
  };

  const handleTextChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      setLocalText(e.target.value);
      if (popover.userId && popover.date) {
          onUpdateText(popover.userId, popover.date, e.target.value);
      }
  };

  // --- Drag & Drop Handlers ---
  const handleDragStart = (e: React.DragEvent, userId: string, date: Date) => {
    // Only allow drag if there is content
    const assignment = getAssignment(userId, date);
    if (!assignment || (assignment.templateIds.length === 0 && !assignment.customText)) {
        e.preventDefault();
        return;
    }
    
    // Set data
    e.dataTransfer.setData('application/json', JSON.stringify({ userId, date: formatDateISO(date) }));
    e.dataTransfer.effectAllowed = 'move';
    
    // Add visual ghost effect
    const target = e.currentTarget as HTMLElement;
    target.style.opacity = '0.5';
  };

  const handleDragEnd = (e: React.DragEvent) => {
    const target = e.currentTarget as HTMLElement;
    target.style.opacity = '1';
    setDragOverCell(null);
  };

  const handleDragOver = (e: React.DragEvent, userId: string, date: Date) => {
    e.preventDefault(); // Necessary to allow dropping
    e.dataTransfer.dropEffect = 'move';
    const dateStr = formatDateISO(date);
    if (dragOverCell?.userId !== userId || dragOverCell?.dateStr !== dateStr) {
        setDragOverCell({ userId, dateStr });
    }
  };

  const handleDrop = (e: React.DragEvent, targetUserId: string, targetDate: Date) => {
    e.preventDefault();
    setDragOverCell(null);
    
    try {
        const data = JSON.parse(e.dataTransfer.getData('application/json'));
        if (data && data.userId && data.date) {
            const sourceDate = new Date(data.date);
            onMoveAssignment(data.userId, sourceDate, targetUserId, targetDate);
        }
    } catch (err) {
        console.error("Drop failed", err);
    }
  };

  return (
    <div className="flex flex-col h-full bg-white dark:bg-slate-800 shadow-sm border dark:border-slate-700 rounded-xl overflow-hidden transition-colors">
      {/* Calendar Header Controls */}
      <div className="flex items-center justify-between p-4 border-b dark:border-slate-700 bg-white dark:bg-slate-800 transition-colors">
        <div className="flex items-center gap-4">
          <div className="flex bg-slate-100 dark:bg-slate-700 rounded-lg p-1 border border-slate-200 dark:border-slate-600">
            <button 
              onClick={() => onDateChange(addDays(currentDate, -7))}
              className="p-1 hover:bg-white dark:hover:bg-slate-600 hover:shadow-sm rounded-md transition-all text-slate-600 dark:text-slate-300"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button 
              onClick={() => onDateChange(new Date())}
              className="px-3 py-1 text-sm font-medium text-slate-600 dark:text-slate-200 hover:bg-white dark:hover:bg-slate-600 hover:shadow-sm rounded-md transition-all"
            >
              Aujourd'hui
            </button>
            <button 
              onClick={() => onDateChange(addDays(currentDate, 7))}
              className="p-1 hover:bg-white dark:hover:bg-slate-600 hover:shadow-sm rounded-md transition-all text-slate-600 dark:text-slate-300"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
          <h2 className="text-lg font-bold text-slate-800 dark:text-white capitalize flex items-center gap-2">
            <CalendarIcon className="w-5 h-5 text-blue-600 dark:text-blue-400" />
            {new Intl.DateTimeFormat('fr-FR', { month: 'long', year: 'numeric' }).format(currentDate)}
          </h2>
          <div className="hidden lg:flex items-center gap-2 ml-4 px-3 py-1 bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-200 rounded-full text-xs font-medium border border-blue-100 dark:border-blue-800">
            <Copy className="w-3 h-3" />
            <span>Astuce : Glisser-déposer pour déplacer, Double-clic pour éditer</span>
          </div>
        </div>
        
        <button 
          onClick={onOpenAdmin}
          className="flex items-center gap-2 px-4 py-2 bg-slate-900 dark:bg-slate-700 text-white text-sm font-medium rounded-lg hover:bg-slate-700 dark:hover:bg-slate-600 transition-colors shadow-sm"
        >
          <Settings className="w-4 h-4" />
          <span>Gérer l'équipe & Modèles</span>
        </button>
      </div>

      {/* Main Grid Area */}
      <div className="flex-1 overflow-auto relative bg-white dark:bg-slate-800">
        <table className="w-full border-collapse min-w-[1000px]">
          <thead className="bg-slate-50 dark:bg-slate-900 sticky top-0 z-10 shadow-sm transition-colors">
            <tr>
              <th className="p-4 text-left border-b border-r dark:border-slate-700 w-64 bg-slate-50 dark:bg-slate-900 sticky left-0 z-20">
                <span className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">Membres</span>
              </th>
              {weekDays.map((date) => {
                const dateISO = formatDateISO(date);
                const isToday = dateISO === todayISO;
                const isHoliday = holidays.includes(dateISO);
                
                return (
                  <th key={dateISO} className={`p-3 text-center border-b border-r dark:border-slate-700 min-w-[120px] relative overflow-hidden ${isToday ? 'bg-blue-50/50 dark:bg-blue-900/20' : ''} ${isHoliday ? 'bg-red-50 dark:bg-red-900/20' : ''}`}>
                    {/* Visual pattern for holiday */}
                    {isHoliday && <div className="absolute inset-0 opacity-10 pointer-events-none" style={{ backgroundImage: 'repeating-linear-gradient(45deg, #ef4444 0, #ef4444 1px, transparent 0, transparent 50%)', backgroundSize: '10px 10px' }}></div>}
                    
                    <div className={`flex flex-col items-center justify-center relative z-10`}>
                      <span className={`text-xs uppercase font-bold mb-1 ${isToday ? 'text-blue-600 dark:text-blue-400' : isHoliday ? 'text-red-600 dark:text-red-400' : 'text-slate-400 dark:text-slate-500'}`}>
                        {new Intl.DateTimeFormat('fr-FR', { weekday: 'short' }).format(date)}
                        {isHoliday && <span className="ml-1 text-[10px]">(Férié)</span>}
                      </span>
                      <span className={`text-xl font-light w-8 h-8 flex items-center justify-center rounded-full ${isToday ? 'bg-blue-600 text-white shadow-md' : isHoliday ? 'text-red-600 dark:text-red-400 font-normal ring-1 ring-red-200 dark:ring-red-800' : 'text-slate-700 dark:text-slate-300'}`}>
                        {date.getDate()}
                      </span>
                    </div>
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody>
            {users.map((user) => (
              <tr key={user.id} className="group hover:bg-slate-50/50 dark:hover:bg-slate-700/30 transition-colors">
                <td className="p-4 border-b border-r dark:border-slate-700 bg-white dark:bg-slate-800 sticky left-0 z-10 group-hover:bg-slate-50/50 dark:group-hover:bg-slate-700/30 border-r-slate-200 dark:border-r-slate-700 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 text-white flex items-center justify-center font-bold shadow-sm">
                       {user.name.charAt(0)}
                    </div>
                    <div>
                      <div className="font-semibold text-slate-900 dark:text-slate-100 text-sm">{user.name}</div>
                      <div className="text-xs text-slate-500 dark:text-slate-400">{user.role}</div>
                    </div>
                  </div>
                </td>
                {weekDays.map((date) => {
                  const dateISO = formatDateISO(date);
                  const assignment = getAssignment(user.id, date);
                  const activeTemplateIds = assignment?.templateIds || [];
                  const hasCustomText = !!assignment?.customText;
                  const isEmpty = activeTemplateIds.length === 0 && !hasCustomText;
                  const isToday = dateISO === todayISO;
                  const isHoliday = holidays.includes(dateISO);
                  const isSelected = selectedCell?.userId === user.id && selectedCell?.date.getTime() === date.getTime();
                  const isDragOver = dragOverCell?.userId === user.id && dragOverCell?.dateStr === dateISO;

                  return (
                    <td 
                      key={dateISO} 
                      className={`p-1 border-b border-r dark:border-slate-700 cursor-pointer relative transition-all align-top h-24 outline-none 
                        ${isToday ? 'bg-blue-50/10 dark:bg-blue-900/10' : ''}
                        ${isHoliday ? 'bg-red-50/30 dark:bg-red-900/10' : ''}
                        ${isDragOver ? 'bg-blue-100 dark:bg-blue-800/50 ring-2 ring-inset ring-blue-400' : 'focus:bg-blue-50/30 dark:focus:bg-blue-900/20'}
                      `}
                      onClick={(e) => handleCellClick(e, user.id, date)}
                      onDoubleClick={(e) => handleCellDoubleClick(e, user.id, date)}
                      onKeyDown={(e) => handleKeyDown(e, user.id, date)}
                      onDragOver={(e) => handleDragOver(e, user.id, date)}
                      onDrop={(e) => handleDrop(e, user.id, date)}
                      tabIndex={0}
                    >
                        {/* Holiday Pattern in background */}
                        {isHoliday && <div className="absolute inset-0 opacity-5 pointer-events-none" style={{ backgroundImage: 'repeating-linear-gradient(45deg, #ef4444 0, #ef4444 1px, transparent 0, transparent 50%)', backgroundSize: '10px 10px' }}></div>}

                        <div 
                            className={`w-full h-full min-h-[5rem] rounded-md transition-all flex flex-col overflow-hidden relative z-10
                            ${isSelected ? 'ring-2 ring-blue-500 z-10' : ''} 
                            ${isEmpty ? 'border-2 border-dashed border-transparent hover:border-blue-200 dark:hover:border-slate-600' : 'bg-white dark:bg-slate-700 shadow-sm border border-slate-200 dark:border-slate-600'}`}
                            draggable={!isEmpty}
                            onDragStart={(e) => handleDragStart(e, user.id, date)}
                            onDragEnd={handleDragEnd}
                        >
                        {isEmpty ? (
                           <div className="w-full h-full flex items-center justify-center">
                              <Plus className={`w-5 h-5 text-slate-300 dark:text-slate-600 ${isSelected ? 'text-blue-400' : ''}`} />
                           </div>
                        ) : (
                          <>
                            {/* Render Badges/Modules Full Size */}
                            <div className="flex-1 flex flex-col w-full h-full">
                                {activeTemplateIds.map(tid => {
                                    const tpl = templates.find(t => t.id === tid);
                                    if (!tpl) return null;
                                    return (
                                        <div 
                                          key={tid} 
                                          className={`flex-1 flex items-center justify-center px-2 text-xs font-bold ${tpl.color} w-full border-b border-black/10 last:border-0`}
                                          title={tpl.label}
                                        >
                                            <span className="truncate text-center shadow-sm">{tpl.label}</span>
                                        </div>
                                    );
                                })}
                            </div>
                            
                            {/* Render Custom Text at bottom if exists */}
                            {hasCustomText && (
                                <div className={`px-1 py-0.5 bg-yellow-50 dark:bg-yellow-900/30 text-[10px] text-slate-700 dark:text-yellow-100 leading-tight border-t border-slate-100 dark:border-slate-600 text-center truncate ${activeTemplateIds.length === 0 ? 'h-full flex items-center justify-center font-medium text-sm' : ''}`}>
                                    {assignment.customText}
                                </div>
                            )}
                          </>
                        )}
                      </div>
                    </td>
                  );
                })}
              </tr>
            ))}
             {users.length === 0 && (
              <tr>
                <td colSpan={8} className="p-12 text-center text-slate-400">
                  Aucun utilisateur défini. Utilisez le panneau d'administration pour commencer.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Popover Selection Menu */}
      {popover.isOpen && popover.userId && popover.date && (
        <div 
          ref={popoverRef}
          className="fixed bg-white dark:bg-slate-800 rounded-xl shadow-2xl border border-slate-200 dark:border-slate-600 z-50 w-72 p-3 animate-in fade-in zoom-in-95 duration-100 flex flex-col gap-3"
          style={{ top: popover.y, left: popover.x }}
        >
          {/* Custom Text Input */}
          <div className="relative">
             <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Type className="h-4 w-4 text-slate-400" />
             </div>
             <input
                autoFocus
                type="text"
                placeholder="Note personnalisée..."
                className="w-full pl-9 pr-3 py-2 text-sm border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white dark:bg-slate-900 dark:border-slate-600 dark:text-white dark:placeholder-slate-500"
                value={localText}
                onChange={handleTextChange}
             />
          </div>

          <div className="h-px bg-slate-100 dark:bg-slate-700"></div>

          {/* Holiday Toggle */}
          <label className="flex items-center gap-3 p-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-700 cursor-pointer border border-transparent hover:border-slate-200 dark:hover:border-slate-600 transition-all">
             <div className={`w-8 h-8 rounded-full flex items-center justify-center transition-colors ${holidays.includes(formatDateISO(popover.date)) ? 'bg-red-100 text-red-600' : 'bg-slate-100 text-slate-400 dark:bg-slate-700'}`}>
                <Flag className="w-4 h-4" />
             </div>
             <div className="flex-1">
                 <div className="text-sm font-medium text-slate-800 dark:text-slate-200">Jour Férié</div>
                 <div className="text-[10px] text-slate-500 dark:text-slate-400">Marquer pour toute l'équipe</div>
             </div>
             <input 
                type="checkbox" 
                className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500"
                checked={holidays.includes(formatDateISO(popover.date))}
                onChange={() => onToggleHoliday(popover.date!)}
             />
          </label>

          <div className="h-px bg-slate-100 dark:bg-slate-700"></div>

          {/* Templates Grid */}
          <div className="space-y-1 max-h-60 overflow-y-auto">
             <div className="text-xs font-bold text-slate-400 uppercase px-1 mb-2">Modules (Multi-sélection)</div>
            {templates.map(tpl => {
               const assignment = getAssignment(popover.userId!, popover.date!);
               const isSelected = assignment?.templateIds.includes(tpl.id);

               return (
                  <button
                    key={tpl.id}
                    onClick={() => onToggleTemplate(popover.userId!, popover.date!, tpl.id)}
                    className={`w-full text-left p-2 rounded-lg text-sm font-medium transition-all flex items-center gap-2 group border ${isSelected ? 'bg-blue-50 dark:bg-blue-900/30 border-blue-200 dark:border-blue-700' : 'border-transparent hover:bg-slate-50 dark:hover:bg-slate-700'}`}
                  >
                    <div className={`w-4 h-4 rounded flex items-center justify-center border ${isSelected ? 'bg-blue-600 border-blue-600' : 'border-slate-300 dark:border-slate-500 bg-white dark:bg-slate-700'}`}>
                        {isSelected && <Check className="w-3 h-3 text-white" />}
                    </div>
                    {/* Color Circle */}
                    <span className={`w-3 h-3 rounded-full ${tpl.color.split(' ')[0]}`}></span>
                    <span className="flex-1 truncate dark:text-slate-200">{tpl.label}</span>
                  </button>
               );
            })}
          </div>
            
          <div className="h-px bg-slate-100 dark:bg-slate-700"></div>
            
          <button
              onClick={() => {
                  onClear(popover.userId!, popover.date!);
                  setPopover({...popover, isOpen: false});
              }}
              className="w-full text-left p-2 rounded-lg text-sm font-medium text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors flex items-center justify-center gap-2"
          >
            <Eraser className="w-4 h-4" />
            Tout effacer
          </button>
        </div>
      )}
    </div>
  );
};