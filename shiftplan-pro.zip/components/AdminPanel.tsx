import React, { useState } from 'react';
import { User, ShiftTemplate } from '../types';
import { COLORS } from '../constants';
import { Trash2, Plus, User as UserIcon, Calendar, X, Pencil, Save, RotateCcw } from 'lucide-react';

interface AdminPanelProps {
  users: User[];
  templates: ShiftTemplate[];
  onAddUser: (u: User) => void;
  onRemoveUser: (id: string) => void;
  onUpdateUser: (u: User) => void;
  onAddTemplate: (t: ShiftTemplate) => void;
  onRemoveTemplate: (id: string) => void;
  onUpdateTemplate: (t: ShiftTemplate) => void;
  onClose: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  users, templates, onAddUser, onRemoveUser, onUpdateUser, onAddTemplate, onRemoveTemplate, onUpdateTemplate, onClose
}) => {
  const [activeTab, setActiveTab] = useState<'users' | 'templates'>('users');
  
  // --- USER STATE ---
  const [editingUserId, setEditingUserId] = useState<string | null>(null);
  const [newUserName, setNewUserName] = useState('');
  const [newUserRole, setNewUserRole] = useState('');

  // --- TEMPLATE STATE ---
  const [editingTemplateId, setEditingTemplateId] = useState<string | null>(null);
  const [newTplLabel, setNewTplLabel] = useState('');
  const [newTplColor, setNewTplColor] = useState(COLORS[0].value);
  const [newTplDesc, setNewTplDesc] = useState('');

  // --- USER ACTIONS ---

  const startEditUser = (user: User) => {
    setEditingUserId(user.id);
    setNewUserName(user.name);
    setNewUserRole(user.role);
  };

  const cancelEditUser = () => {
    setEditingUserId(null);
    setNewUserName('');
    setNewUserRole('');
  };

  const handleUserSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUserName.trim()) return;

    if (editingUserId) {
        // UPDATE Existing
        onUpdateUser({
            id: editingUserId,
            name: newUserName,
            role: newUserRole || 'Employé'
        });
        setEditingUserId(null);
    } else {
        // CREATE New
        onAddUser({
            id: crypto.randomUUID(),
            name: newUserName,
            role: newUserRole || 'Employé'
        });
    }
    setNewUserName('');
    setNewUserRole('');
  };

  // --- TEMPLATE ACTIONS ---

  const startEditTemplate = (tpl: ShiftTemplate) => {
    setEditingTemplateId(tpl.id);
    setNewTplLabel(tpl.label);
    setNewTplColor(tpl.color);
    setNewTplDesc(tpl.description || '');
  };

  const cancelEditTemplate = () => {
    setEditingTemplateId(null);
    setNewTplLabel('');
    setNewTplColor(COLORS[0].value);
    setNewTplDesc('');
  };

  const handleTemplateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTplLabel.trim()) return;

    if (editingTemplateId) {
        // UPDATE Existing
        onUpdateTemplate({
            id: editingTemplateId,
            label: newTplLabel,
            code: newTplLabel.substring(0, 3).toUpperCase(),
            color: newTplColor,
            description: newTplDesc
        });
        setEditingTemplateId(null);
    } else {
        // CREATE New
        onAddTemplate({
            id: crypto.randomUUID(),
            label: newTplLabel,
            code: newTplLabel.substring(0, 3).toUpperCase(), // Auto-generate simple code for fallback
            color: newTplColor,
            description: newTplDesc
        });
    }
    
    setNewTplLabel('');
    setNewTplDesc('');
    // We keep the color selection or reset it? Let's keep it for ease of creating multiple similar ones, 
    // or reset if it was an edit.
    if (editingTemplateId) {
        setNewTplColor(COLORS[0].value);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
      <div className="bg-white dark:bg-slate-800 w-full max-w-2xl rounded-xl shadow-2xl flex flex-col max-h-[90vh] animate-in fade-in zoom-in duration-200 transition-colors">
        
        {/* Header */}
        <div className="p-6 border-b dark:border-slate-700 flex justify-between items-center bg-slate-50 dark:bg-slate-800/50 rounded-t-xl">
          <h2 className="text-2xl font-bold text-slate-800 dark:text-white">Administration</h2>
          <button onClick={onClose} className="p-2 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-full transition-colors">
            <X className="w-6 h-6 text-slate-500 dark:text-slate-400" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b dark:border-slate-700">
          <button
            onClick={() => { setActiveTab('users'); cancelEditTemplate(); }}
            className={`flex-1 py-4 text-sm font-semibold flex items-center justify-center gap-2 transition-colors ${activeTab === 'users' ? 'text-blue-600 border-b-2 border-blue-600 bg-blue-50/50 dark:bg-blue-900/10' : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'}`}
          >
            <UserIcon className="w-4 h-4" />
            Utilisateurs
          </button>
          <button
            onClick={() => { setActiveTab('templates'); cancelEditUser(); }}
            className={`flex-1 py-4 text-sm font-semibold flex items-center justify-center gap-2 transition-colors ${activeTab === 'templates' ? 'text-blue-600 border-b-2 border-blue-600 bg-blue-50/50 dark:bg-blue-900/10' : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'}`}
          >
            <Calendar className="w-4 h-4" />
            Modèles (Modules)
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 bg-white dark:bg-slate-800">
          
          {activeTab === 'users' && (
            <div className="space-y-6">
              <form onSubmit={handleUserSubmit} className={`p-4 rounded-lg border space-y-4 transition-colors ${editingUserId ? 'bg-amber-50 dark:bg-amber-900/10 border-amber-200 dark:border-amber-700' : 'bg-slate-50 dark:bg-slate-900/50 border-slate-200 dark:border-slate-700'}`}>
                <div className="flex items-center justify-between">
                    <h3 className={`font-semibold text-sm uppercase tracking-wide ${editingUserId ? 'text-amber-600 dark:text-amber-400' : 'text-slate-500'}`}>
                        {editingUserId ? 'Modifier l\'utilisateur' : 'Ajouter un utilisateur'}
                    </h3>
                    {editingUserId && (
                        <button type="button" onClick={cancelEditUser} className="text-xs text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200 flex items-center gap-1">
                            <RotateCcw className="w-3 h-3"/> Annuler
                        </button>
                    )}
                </div>
                
                <div className="flex gap-3">
                  <input
                    type="text"
                    placeholder="Nom complet"
                    className="flex-1 px-3 py-2 border dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white dark:bg-slate-800 dark:text-white dark:placeholder-slate-500"
                    value={newUserName}
                    onChange={(e) => setNewUserName(e.target.value)}
                  />
                  <input
                    type="text"
                    placeholder="Rôle (ex: Manager)"
                    className="flex-1 px-3 py-2 border dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white dark:bg-slate-800 dark:text-white dark:placeholder-slate-500"
                    value={newUserRole}
                    onChange={(e) => setNewUserRole(e.target.value)}
                  />
                  <button 
                    type="submit" 
                    className={`text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors ${editingUserId ? 'bg-amber-600 hover:bg-amber-700' : 'bg-blue-600 hover:bg-blue-700'}`}
                  >
                    {editingUserId ? <Save className="w-4 h-4" /> : <Plus className="w-4 h-4" />} 
                    {editingUserId ? 'Enregistrer' : 'Ajouter'}
                  </button>
                </div>
              </form>

              <div className="space-y-2">
                {users.map(user => (
                  <div key={user.id} className={`flex items-center justify-between p-3 border dark:border-slate-700 rounded-lg hover:shadow-sm transition-all ${editingUserId === user.id ? 'ring-2 ring-amber-400 bg-amber-50 dark:bg-amber-900/20' : 'bg-white dark:bg-slate-700/50'}`}>
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-slate-200 dark:bg-slate-600 flex items-center justify-center text-slate-600 dark:text-slate-200 font-bold text-xs">
                        {user.name.substring(0, 2).toUpperCase()}
                      </div>
                      <div>
                        <div className="font-medium text-slate-800 dark:text-slate-100">{user.name}</div>
                        <div className="text-xs text-slate-500 dark:text-slate-400">{user.role}</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-1">
                        <button 
                          onClick={() => startEditUser(user)}
                          className="text-slate-400 hover:text-blue-600 p-2 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-full transition-colors"
                          title="Modifier"
                        >
                          <Pencil className="w-4 h-4" />
                        </button>
                        <button 
                          onClick={() => onRemoveUser(user.id)}
                          className="text-slate-400 hover:text-red-600 p-2 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-full transition-colors"
                          title="Supprimer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                    </div>
                  </div>
                ))}
                {users.length === 0 && <p className="text-center text-slate-400 py-4">Aucun utilisateur.</p>}
              </div>
            </div>
          )}

          {activeTab === 'templates' && (
            <div className="space-y-6">
              <form onSubmit={handleTemplateSubmit} className={`p-4 rounded-lg border space-y-4 transition-colors ${editingTemplateId ? 'bg-amber-50 dark:bg-amber-900/10 border-amber-200 dark:border-amber-700' : 'bg-slate-50 dark:bg-slate-900/50 border-slate-200 dark:border-slate-700'}`}>
                <div className="flex items-center justify-between">
                    <h3 className={`font-semibold text-sm uppercase tracking-wide ${editingTemplateId ? 'text-amber-600 dark:text-amber-400' : 'text-slate-500'}`}>
                        {editingTemplateId ? 'Modifier le modèle' : 'Créer un modèle'}
                    </h3>
                    {editingTemplateId && (
                        <button type="button" onClick={cancelEditTemplate} className="text-xs text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200 flex items-center gap-1">
                            <RotateCcw className="w-3 h-3"/> Annuler
                        </button>
                    )}
                </div>

                <div className="grid grid-cols-1 gap-3">
                  <input
                    type="text"
                    placeholder="Nom du module (ex: 08h-16h, Télétravail)"
                    className="px-3 py-2 border dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white dark:bg-slate-800 dark:text-white dark:placeholder-slate-500"
                    value={newTplLabel}
                    onChange={(e) => setNewTplLabel(e.target.value)}
                  />
                  <input
                    type="text"
                    placeholder="Description (optionnel)"
                    className="px-3 py-2 border dark:border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white dark:bg-slate-800 dark:text-white dark:placeholder-slate-500"
                    value={newTplDesc}
                    onChange={(e) => setNewTplDesc(e.target.value)}
                  />
                </div>
                
                <div>
                  <label className="text-xs font-semibold text-slate-500 mb-2 block">Couleur</label>
                  <div className="flex flex-wrap gap-2">
                    {COLORS.map(c => (
                      <button
                        key={c.name}
                        type="button"
                        onClick={() => setNewTplColor(c.value)}
                        className={`w-8 h-8 rounded-full shadow-sm transition-transform hover:scale-110 ${c.value.split(' ')[0]} ${newTplColor === c.value ? 'ring-2 ring-offset-2 ring-blue-500 dark:ring-offset-slate-900' : ''}`}
                        title={c.name}
                      />
                    ))}
                  </div>
                  {/* Preview of the created module */}
                  {newTplLabel && (
                     <div className="mt-4">
                        <span className="text-xs text-slate-400 block mb-1">Aperçu :</span>
                        <div className={`inline-flex items-center justify-center px-4 py-2 rounded-md font-bold shadow-sm ${newTplColor}`}>
                           {newTplLabel}
                        </div>
                     </div>
                  )}
                </div>

                <div className="flex justify-end">
                   <button 
                        type="submit" 
                        className={`text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors ${editingTemplateId ? 'bg-amber-600 hover:bg-amber-700' : 'bg-blue-600 hover:bg-blue-700'}`}
                    >
                    {editingTemplateId ? <Save className="w-4 h-4" /> : <Plus className="w-4 h-4" />} 
                    {editingTemplateId ? 'Enregistrer le modèle' : 'Créer le modèle'}
                  </button>
                </div>
              </form>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {templates.map(tpl => (
                  <div key={tpl.id} className={`flex items-center justify-between p-3 border dark:border-slate-600 rounded-lg hover:shadow-sm transition-all border-l-4 dark:bg-slate-700/30 ${tpl.color.replace('bg-', 'border-').split(' ')[0]} ${editingTemplateId === tpl.id ? 'ring-2 ring-amber-400 bg-amber-50 dark:bg-amber-900/20' : ''}`}>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                         {/* Show a mini preview of the style */}
                         <span className={`w-3 h-3 rounded-full ${tpl.color.split(' ')[0]}`}></span>
                         <span className="font-bold text-slate-800 dark:text-slate-100">{tpl.label}</span>
                      </div>
                      {tpl.description && <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">{tpl.description}</div>}
                    </div>
                    <div className="flex items-center gap-1">
                        <button 
                          onClick={() => startEditTemplate(tpl)}
                          className="text-slate-400 hover:text-blue-600 p-2 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-full transition-colors"
                          title="Modifier"
                        >
                          <Pencil className="w-4 h-4" />
                        </button>
                        <button 
                          onClick={() => onRemoveTemplate(tpl.id)}
                          className="text-slate-400 hover:text-red-600 p-2 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-full transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};