import { User, ShiftTemplate } from './types';

// Updated to Solid Colors (White text on Dark Background) for better visibility like Teams
export const COLORS = [
  { name: 'Bleu', value: 'bg-blue-600 text-white border-blue-700' },
  { name: 'Vert', value: 'bg-emerald-600 text-white border-emerald-700' },
  { name: 'Rouge', value: 'bg-red-600 text-white border-red-700' },
  { name: 'Orange', value: 'bg-orange-500 text-white border-orange-600' },
  { name: 'Violet', value: 'bg-purple-600 text-white border-purple-700' },
  { name: 'Gris', value: 'bg-slate-500 text-white border-slate-600' },
  { name: 'Rose', value: 'bg-pink-600 text-white border-pink-700' },
  { name: 'Indigo', value: 'bg-indigo-600 text-white border-indigo-700' },
  { name: 'Sarcelle', value: 'bg-teal-600 text-white border-teal-700' },
];

export const INITIAL_USERS: User[] = [];

export const INITIAL_TEMPLATES: ShiftTemplate[] = [];