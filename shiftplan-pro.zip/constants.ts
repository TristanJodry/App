import { User, ShiftTemplate } from './types';

// Updated to Solid Colors (White text on Dark Background) for better visibility like Teams
export const COLORS = [
  { name: 'Bleu', value: 'bg-blue-600 text-white border-blue-700' },
  { name: 'Vert', value: 'bg-emerald-600 text-white border-emerald-700' },
  { name: 'Rouge', value: 'bg-red-600 text-white border-red-700' },
  { name: 'Orange', value: 'bg-orange-500 text-white border-orange-600' },
  { name: 'Violet', value: 'bg-purple-600 text-white border-purple-700' },
  { name: 'Gris', value: 'bg-slate-500 text-white border-slate-600' },
  { name: 'Rose', value: 'bg-pink-600 text-white border-pink-700' },
  { name: 'Indigo', value: 'bg-indigo-600 text-white border-indigo-700' },
  { name: 'Sarcelle', value: 'bg-teal-600 text-white border-teal-700' },
];

export const INITIAL_USERS: User[] = [
  { id: '1', name: 'Alice Dupont', role: 'Manager' },
  { id: '2', name: 'Bob Martin', role: 'Développeur' },
  { id: '3', name: 'Charlie Leroy', role: 'Designer' },
  { id: '4', name: 'David Smith', role: 'Support' },
];

export const INITIAL_TEMPLATES: ShiftTemplate[] = [
  { id: 't1', label: '09:00 - 17:00', code: '9h', color: 'bg-blue-600 text-white border-blue-700', description: 'Journée standard' },
  { id: 't2', label: 'Télétravail', code: 'TT', color: 'bg-purple-600 text-white border-purple-700', description: 'Travail à domicile' },
  { id: 't3', label: 'Matin', code: 'AM', color: 'bg-emerald-600 text-white border-emerald-700', description: '08:00 - 12:00' },
  { id: 't4', label: 'Après-midi', code: 'PM', color: 'bg-orange-500 text-white border-orange-600', description: '13:00 - 18:00' },
  { id: 't5', label: 'Congés', code: 'OFF', color: 'bg-slate-500 text-white border-slate-600', description: 'Absence' },
];